# Core platform roadmap

- [x] Responsive classic-inspired shell
- [x] Browser-playable 3D obby
- [x] Supabase auth integration point
- [x] Profile table
- [x] Avatar color loadout starter
- [x] Friend request starter flow
- [x] Direct message starter flow
- [x] Global chat starter (manual refresh)
- [x] Group creation/join starter
- [x] Game catalogue draft starter
- [x] User report submission starter
- [x] PWA manifest/service worker starter
- [ ] Shared multiplayer servers
- [ ] Game creation engine and safe hosting pipeline
- [ ] Real-time chat, moderation, block/mute and rate limits
- [ ] Full avatar/catalog/inventory/economy systems
- [ ] Notifications, badges, search, discovery and analytics
- [ ] Admin/moderation dashboard and secure server-side actions
- [ ] Account deletion/export, privacy policy, terms, backups and production security review

The checked items are starter implementations, not a claim of production readiness. See README.md.
