# Lodinka — expanded starter

An original, classic-inspired block platform prototype. This is **not a copy of Roblox** and is not a complete recreation of Roblox in 2019. It includes one playable browser-based 3D obby, a classic-inspired website shell, Supabase account integration points, and starter screens/database tables for core community features.

## Files
- `index.html` — responsive site, account form, playable 3D obby, avatar colour editor, friends, direct messages, global chat, groups, game-listing drafts and reports.
- `supabase.sql` — profile table and basic profile policies.
- `platform.sql` — starter tables and policies for friend requests, direct messages, avatar loadouts, inventory, global chat, groups, game catalogue and user reports.
- `manifest.json`, `sw.js` — basic PWA setup.
- `README.md` — this guide.

## Publish from an Android phone
1. Extract the ZIP using your file manager.
2. In GitHub, create a repository named `lodinka`.
3. Upload the files in this folder to the repository root (not the ZIP itself).
4. Open repository **Settings → Pages**.
5. Choose **Deploy from a branch**, branch `main`, folder `/(root)`, then Save.
6. Wait for the Pages URL to appear, then open it.

## Connect real online accounts and community features
1. Create a Supabase project.
2. In Supabase, open **SQL Editor**.
3. Run `supabase.sql` first, then run `platform.sql`.
4. Open `index.html` in GitHub's editor.
5. Find `PASTE_YOUR_SUPABASE_PROJECT_URL` and `PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`.
6. Replace those two values with your project's Project URL and publishable key (older projects may call it the anon key).
7. Commit the change and wait for GitHub Pages to update.
8. In Supabase Auth, set the allowed site/redirect URLs to your exact GitHub Pages URL. Email confirmation settings affect the sign-up flow.
9. Test with two separate test accounts. Never use a real password you use elsewhere.

The publishable/anon key is intended for browser use only when Row Level Security (RLS) is configured correctly. **Never put a service-role or secret key in `index.html`**. Review Supabase's security guidance before public launch:
- https://supabase.com/docs/guides/database/secure-data
- https://supabase.com/docs/guides/security/product-security

## What works in this starter
- One browser-playable 3D obstacle course with keyboard and mobile controls.
- Email/password account UI when connected to Supabase.
- Profile username storage.
- Basic avatar colour saving.
- Friend request sending and accept/decline interface.
- Basic direct-message interface.
- Basic global chat (manual refresh).
- Group creation and joining.
- Save a draft game catalogue entry.
- Submit a user report.
- PWA files for installability checks.

## What is still NOT a complete Roblox-like platform
The screens and database tables are foundations; they still need careful testing and hardening. This package does not include:
- Roblox's full 2019 feature set, exact UI, proprietary models, catalog or games.
- A multiplayer game server or shared live 3D world.
- A complete game engine/editor, secure game upload/hosting, or a game moderation/publishing pipeline.
- Real-time chat subscriptions, message deletion, block/mute, spam controls, automated moderation or staff dashboards.
- A complete avatar catalog, clothing/animation system, trading, badges, achievements, groups walls, notifications, search, recommendations or monetisation.
- A secure username-reservation workflow for concurrent signups.
- A trusted backend for admin powers, inventory grants, game publishing, report review or account deletion.
- A privacy policy, terms, support workflow, abuse response plan, backups or production testing.

**Do not invite the public until you add moderation, rate limiting, privacy/terms, account deletion, and test all database policies.** Database policies are security-critical. Test with multiple accounts and inspect the Supabase Security Advisor.

## Android app
First publish the site over HTTPS. Then use PWABuilder's current packaging flow to check the PWA and package it for Android. The available output can vary; an Android App Bundle (AAB) is not the same as an installable APK. This ZIP itself is a website starter, not an APK.

## Legal and naming
Use your own name, logo, art, sounds, and game assets. Make clear that this is an independent project and is not affiliated with Roblox Corporation.
