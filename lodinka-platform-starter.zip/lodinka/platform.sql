-- Lodinka: community features schema
-- Run this AFTER supabase.sql in Supabase SQL Editor.
-- Review policies and test with two separate accounts before inviting users.

create table if not exists public.friend_requests (
  id bigint generated always as identity primary key,
  sender uuid not null references auth.users(id) on delete cascade,
  receiver uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined')),
  created_at timestamptz not null default now(),
  unique(sender, receiver),
  check (sender <> receiver)
);
alter table public.friend_requests enable row level security;
drop policy if exists "Users can view their own friend requests" on public.friend_requests;
create policy "Users can view their own friend requests" on public.friend_requests for select to authenticated using (auth.uid() = sender or auth.uid() = receiver);
drop policy if exists "Users can send friend requests" on public.friend_requests;
create policy "Users can send friend requests" on public.friend_requests for insert to authenticated with check (auth.uid() = sender);
drop policy if exists "Receiver can respond to friend requests" on public.friend_requests;
create policy "Receiver can respond to friend requests" on public.friend_requests for update to authenticated using (auth.uid() = receiver) with check (auth.uid() = receiver);
grant select, insert, update on public.friend_requests to authenticated;
grant usage, select on sequence public.friend_requests_id_seq to authenticated;

create table if not exists public.direct_messages (
  id bigint generated always as identity primary key,
  sender uuid not null references auth.users(id) on delete cascade,
  receiver uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now(),
  check (sender <> receiver)
);
alter table public.direct_messages enable row level security;
drop policy if exists "Participants can read their messages" on public.direct_messages;
create policy "Participants can read their messages" on public.direct_messages for select to authenticated using (auth.uid() = sender or auth.uid() = receiver);
drop policy if exists "Users can send messages as themselves" on public.direct_messages;
create policy "Users can send messages as themselves" on public.direct_messages for insert to authenticated with check (auth.uid() = sender);
grant select, insert on public.direct_messages to authenticated;
grant usage, select on sequence public.direct_messages_id_seq to authenticated;
create index if not exists direct_messages_pair_time on public.direct_messages (sender, receiver, created_at);

create table if not exists public.avatar_loadouts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  body_color text not null default '#f0c9a4',
  shirt_color text not null default '#1676d2',
  pants_color text not null default '#34465d',
  updated_at timestamptz not null default now()
);
alter table public.avatar_loadouts enable row level security;
drop policy if exists "Avatar loadouts are public" on public.avatar_loadouts;
create policy "Avatar loadouts are public" on public.avatar_loadouts for select to anon, authenticated using (true);
drop policy if exists "Users manage their own avatar" on public.avatar_loadouts;
create policy "Users manage their own avatar" on public.avatar_loadouts for all to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select on public.avatar_loadouts to anon, authenticated;
grant insert, update, delete on public.avatar_loadouts to authenticated;

create table if not exists public.inventory_items (
  id bigint generated always as identity primary key,
  owner_id uuid not null references auth.users(id) on delete cascade,
  item_name text not null check (char_length(item_name) between 1 and 60),
  item_type text not null default 'accessory' check (item_type in ('accessory','shirt','pants','badge')),
  created_at timestamptz not null default now()
);
alter table public.inventory_items enable row level security;
drop policy if exists "Users can see their own inventory" on public.inventory_items;
create policy "Users can see their own inventory" on public.inventory_items for select to authenticated using (auth.uid() = owner_id);
grant select on public.inventory_items to authenticated;
-- Only trusted admin/server code should grant inventory items.

create table if not exists public.global_messages (
  id bigint generated always as identity primary key,
  sender uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);
alter table public.global_messages enable row level security;
drop policy if exists "Signed-in users can read global chat" on public.global_messages;
create policy "Signed-in users can read global chat" on public.global_messages for select to authenticated using (true);
drop policy if exists "Signed-in users can post as themselves" on public.global_messages;
create policy "Signed-in users can post as themselves" on public.global_messages for insert to authenticated with check (auth.uid() = sender);
grant select, insert on public.global_messages to authenticated;
grant usage, select on sequence public.global_messages_id_seq to authenticated;

create table if not exists public.groups (
  id bigint generated always as identity primary key,
  name text not null unique check (char_length(name) between 3 and 40),
  description text not null default '' check (char_length(description) <= 500),
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.groups enable row level security;
drop policy if exists "Groups are publicly visible" on public.groups;
create policy "Groups are publicly visible" on public.groups for select to anon, authenticated using (true);
drop policy if exists "Users create groups as themselves" on public.groups;
create policy "Users create groups as themselves" on public.groups for insert to authenticated with check (auth.uid() = owner_id);
drop policy if exists "Owners update their groups" on public.groups;
create policy "Owners update their groups" on public.groups for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
grant select on public.groups to anon, authenticated;
grant insert, update on public.groups to authenticated;
grant usage, select on sequence public.groups_id_seq to authenticated;

create table if not exists public.group_members (
  group_id bigint not null references public.groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null default 'member' check (role in ('owner','member')),
  joined_at timestamptz not null default now(),
  primary key (group_id, user_id)
);
alter table public.group_members enable row level security;
drop policy if exists "Group membership visible to signed in users" on public.group_members;
create policy "Group membership visible to signed in users" on public.group_members for select to authenticated using (true);
drop policy if exists "Users can join as themselves" on public.group_members;
create policy "Users can join as themselves" on public.group_members for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can leave themselves" on public.group_members;
create policy "Users can leave themselves" on public.group_members for delete to authenticated using (auth.uid() = user_id);
grant select, insert, delete on public.group_members to authenticated;

create table if not exists public.game_catalog (
  id bigint generated always as identity primary key,
  title text not null check (char_length(title) between 3 and 80),
  description text not null default '' check (char_length(description) <= 1000),
  thumbnail_url text not null default '',
  launch_path text not null default '',
  creator_id uuid references auth.users(id) on delete set null,
  published boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.game_catalog enable row level security;
drop policy if exists "Published games are visible" on public.game_catalog;
create policy "Published games are visible" on public.game_catalog for select to anon, authenticated using (published = true or auth.uid() = creator_id);
drop policy if exists "Creators can add their own game entries" on public.game_catalog;
create policy "Creators can add their own game entries" on public.game_catalog for insert to authenticated with check (auth.uid() = creator_id and published = false);
drop policy if exists "Creators can update their own game entries" on public.game_catalog;
create policy "Creators can update their own game entries" on public.game_catalog for update to authenticated using (auth.uid() = creator_id) with check (auth.uid() = creator_id and published = false);
grant select on public.game_catalog to anon, authenticated;
grant insert, update on public.game_catalog to authenticated;
grant usage, select on sequence public.game_catalog_id_seq to authenticated;

create table if not exists public.user_reports (
  id bigint generated always as identity primary key,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reported_user uuid references auth.users(id) on delete set null,
  reason text not null check (char_length(reason) between 5 and 1000),
  status text not null default 'open' check (status in ('open','reviewing','closed')),
  created_at timestamptz not null default now()
);
alter table public.user_reports enable row level security;
drop policy if exists "Users can submit reports" on public.user_reports;
create policy "Users can submit reports" on public.user_reports for insert to authenticated with check (auth.uid() = reporter_id);
drop policy if exists "Users can only see reports they submitted" on public.user_reports;
create policy "Users can only see reports they submitted" on public.user_reports for select to authenticated using (auth.uid() = reporter_id);
grant insert, select on public.user_reports to authenticated;
grant usage, select on sequence public.user_reports_id_seq to authenticated;
